import express from "express";
import { createServer as createViteServer } from "vite";
import Database from "better-sqlite3";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const db = new Database("workout.db");

// Initialize database
db.exec(`
  CREATE TABLE IF NOT EXISTS exercises (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT UNIQUE NOT NULL,
    category TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS workout_sessions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    date TEXT DEFAULT CURRENT_TIMESTAMP,
    notes TEXT
  );

  CREATE TABLE IF NOT EXISTS workout_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id INTEGER NOT NULL,
    exercise_id INTEGER NOT NULL,
    set_number INTEGER NOT NULL,
    reps INTEGER NOT NULL,
    weight REAL NOT NULL,
    FOREIGN KEY (session_id) REFERENCES workout_sessions(id),
    FOREIGN KEY (exercise_id) REFERENCES exercises(id)
  );
`);

// Seed some exercises if empty
const exerciseCount = db.prepare("SELECT COUNT(*) as count FROM exercises").get() as { count: number };
if (exerciseCount.count === 0) {
  const insert = db.prepare("INSERT INTO exercises (name, category) VALUES (?, ?)");
  const defaultExercises = [
    ["Bench Press", "Chest"],
    ["Squat", "Legs"],
    ["Deadlift", "Back"],
    ["Overhead Press", "Shoulders"],
    ["Barbell Row", "Back"],
    ["Pull-ups", "Back"],
    ["Dumbbell Curls", "Arms"],
    ["Tricep Pushdowns", "Arms"]
  ];
  for (const [name, cat] of defaultExercises) {
    insert.run(name, cat);
  }
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // API Routes
  app.get("/api/exercises", (req, res) => {
    const exercises = db.prepare("SELECT * FROM exercises ORDER BY name").all();
    res.json(exercises);
  });

  app.get("/api/history", (req, res) => {
    const history = db.prepare(`
      SELECT 
        s.id as sessionId, 
        s.date, 
        s.notes,
        e.name as exerciseName,
        l.set_number as setNumber,
        l.reps,
        l.weight
      FROM workout_sessions s
      JOIN workout_logs l ON s.id = l.session_id
      JOIN exercises e ON l.exercise_id = e.id
      ORDER BY s.date DESC, l.id ASC
    `).all();

    // Group by session
    const sessions = history.reduce((acc: any[], row: any) => {
      let session = acc.find(s => s.id === row.sessionId);
      if (!session) {
        session = { id: row.sessionId, date: row.date, notes: row.notes, exercises: [] };
        acc.push(session);
      }
      
      let exercise = session.exercises.find((e: any) => e.name === row.exerciseName);
      if (!exercise) {
        exercise = { name: row.exerciseName, sets: [] };
        session.exercises.push(exercise);
      }
      
      exercise.sets.push({ setNumber: row.setNumber, reps: row.reps, weight: row.weight });
      return acc;
    }, []);

    res.json(sessions);
  });

  app.post("/api/logs", (req, res) => {
    const { date, notes, exercises } = req.body;
    
    const insertSession = db.prepare("INSERT INTO workout_sessions (date, notes) VALUES (?, ?)");
    const insertLog = db.prepare("INSERT INTO workout_logs (session_id, exercise_id, set_number, reps, weight) VALUES (?, ?, ?, ?, ?)");

    const transaction = db.transaction(() => {
      const sessionResult = insertSession.run(date || new Date().toISOString(), notes || "");
      const sessionId = sessionResult.lastInsertRowid;

      for (const ex of exercises) {
        for (let i = 0; i < ex.sets.length; i++) {
          const set = ex.sets[i];
          insertLog.run(sessionId, ex.exerciseId, i + 1, set.reps, set.weight);
        }
      }
      return sessionId;
    });

    try {
      const sessionId = transaction();
      res.json({ success: true, sessionId });
    } catch (error) {
      console.error(error);
      res.status(500).json({ error: "Failed to save workout" });
    }
  });

  app.get("/api/stats/:exerciseId", (req, res) => {
    const { exerciseId } = req.params;
    const stats = db.prepare(`
      SELECT 
        s.date,
        MAX(l.weight) as maxWeight,
        SUM(l.reps * l.weight) as volume
      FROM workout_sessions s
      JOIN workout_logs l ON s.id = l.session_id
      WHERE l.exercise_id = ?
      GROUP BY s.date
      ORDER BY s.date ASC
    `).all(exerciseId);
    res.json(stats);
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.join(__dirname, "dist")));
    app.get("*", (req, res) => {
      res.sendFile(path.join(__dirname, "dist", "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
