# IronTrack: Workout Progress Tracker

A comprehensive, full-stack workout logger and progress tracker built with React, Express, and SQLite.

## Features
- **Real-time Logging**: Track sets, reps, and weights for various exercises.
- **Progress Analytics**: Interactive charts visualizing Max Weight and Total Volume over time using Recharts.
- **Workout History**: Detailed log of all past sessions.
- **Full-Stack Architecture**: Express backend with SQLite persistence.
- **Responsive Design**: Modern, mobile-first UI built with Tailwind CSS and Framer Motion.

## Tech Stack
- **Frontend**: React 19, Vite, Tailwind CSS, Recharts, Lucide Icons, Motion.
- **Backend**: Node.js, Express, better-sqlite3.
- **Database**: SQLite.

## Getting Started

### Prerequisites
- Node.js (v18 or higher)
- npm

### Installation
1. Clone the repository:
   ```bash
   git clone <your-repo-url>
   cd workout-tracker
   ```
2. Install dependencies:
   ```bash
   npm install
   ```

### Development
Start the development server (Express + Vite):
```bash
npm run dev
```
The app will be available at `http://localhost:3000`.

### Production
Build the application:
```bash
npm run build
npm start
```

## License
MIT
