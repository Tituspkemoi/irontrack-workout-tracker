import { useState, useEffect } from "react";
import { 
  Plus, 
  History, 
  TrendingUp, 
  Dumbbell, 
  ChevronRight, 
  Trash2, 
  Save,
  Calendar,
  ChevronDown,
  ChevronUp,
  Activity
} from "lucide-react";
import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  AreaChart,
  Area
} from "recharts";
import { motion, AnimatePresence } from "motion/react";
import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

type Exercise = {
  id: number;
  name: string;
  category: string;
};

type Set = {
  reps: number;
  weight: number;
};

type LoggedExercise = {
  exerciseId: number;
  name: string;
  sets: Set[];
};

type WorkoutSession = {
  id: number;
  date: string;
  notes: string;
  exercises: {
    name: string;
    sets: { setNumber: number; reps: number; weight: number }[];
  }[];
};

type Stat = {
  date: string;
  maxWeight: number;
  volume: number;
};

export default function App() {
  const [activeTab, setActiveTab] = useState<"log" | "history" | "stats">("log");
  const [exercises, setExercises] = useState<Exercise[]>([]);
  const [history, setHistory] = useState<WorkoutSession[]>([]);
  const [selectedExerciseId, setSelectedExerciseId] = useState<number | null>(null);
  const [stats, setStats] = useState<Stat[]>([]);
  
  // Current workout state
  const [currentWorkout, setCurrentWorkout] = useState<LoggedExercise[]>([]);
  const [isSaving, setIsSaving] = useState(false);

  useEffect(() => {
    fetchExercises();
    fetchHistory();
  }, []);

  useEffect(() => {
    if (selectedExerciseId) {
      fetchStats(selectedExerciseId);
    }
  }, [selectedExerciseId]);

  const fetchExercises = async () => {
    const res = await fetch("/api/exercises");
    const data = await res.json();
    setExercises(data);
  };

  const fetchHistory = async () => {
    const res = await fetch("/api/history");
    const data = await res.json();
    setHistory(data);
  };

  const fetchStats = async (id: number) => {
    const res = await fetch(`/api/stats/${id}`);
    const data = await res.json();
    setStats(data.map((s: any) => ({
      ...s,
      date: new Date(s.date).toLocaleDateString()
    })));
  };

  const addExerciseToWorkout = (exercise: Exercise) => {
    if (currentWorkout.find(ex => ex.exerciseId === exercise.id)) return;
    setCurrentWorkout([...currentWorkout, { 
      exerciseId: exercise.id, 
      name: exercise.name, 
      sets: [{ reps: 0, weight: 0 }] 
    }]);
  };

  const addSet = (exerciseId: number) => {
    setCurrentWorkout(currentWorkout.map(ex => {
      if (ex.exerciseId === exerciseId) {
        return { ...ex, sets: [...ex.sets, { reps: 0, weight: 0 }] };
      }
      return ex;
    }));
  };

  const updateSet = (exerciseId: number, setIndex: number, field: keyof Set, value: number) => {
    setCurrentWorkout(currentWorkout.map(ex => {
      if (ex.exerciseId === exerciseId) {
        const newSets = [...ex.sets];
        newSets[setIndex] = { ...newSets[setIndex], [field]: value };
        return { ...ex, sets: newSets };
      }
      return ex;
    }));
  };

  const removeExercise = (exerciseId: number) => {
    setCurrentWorkout(currentWorkout.filter(ex => ex.exerciseId !== exerciseId));
  };

  const saveWorkout = async () => {
    if (currentWorkout.length === 0) return;
    setIsSaving(true);
    try {
      const res = await fetch("/api/logs", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          exercises: currentWorkout,
          date: new Date().toISOString()
        })
      });
      if (res.ok) {
        setCurrentWorkout([]);
        fetchHistory();
        setActiveTab("history");
      }
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="min-h-screen bg-zinc-50 text-zinc-900 font-sans pb-20">
      {/* Header */}
      <header className="bg-white border-b border-zinc-200 sticky top-0 z-10">
        <div className="max-w-2xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="bg-emerald-500 p-2 rounded-xl text-white">
              <Dumbbell size={24} />
            </div>
            <h1 className="text-xl font-bold tracking-tight">IronTrack</h1>
          </div>
          <div className="flex items-center gap-2 text-zinc-500 text-sm font-medium">
            <Calendar size={16} />
            {new Date().toLocaleDateString(undefined, { weekday: 'short', month: 'short', day: 'numeric' })}
          </div>
        </div>
      </header>

      <main className="max-w-2xl mx-auto px-4 py-6">
        <AnimatePresence mode="wait">
          {activeTab === "log" && (
            <motion.div
              key="log"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="space-y-6"
            >
              <div className="flex items-center justify-between">
                <h2 className="text-2xl font-bold">Log Workout</h2>
                {currentWorkout.length > 0 && (
                  <button
                    onClick={saveWorkout}
                    disabled={isSaving}
                    className="bg-emerald-500 hover:bg-emerald-600 text-white px-4 py-2 rounded-xl font-semibold flex items-center gap-2 transition-colors disabled:opacity-50"
                  >
                    <Save size={18} />
                    {isSaving ? "Saving..." : "Finish"}
                  </button>
                )}
              </div>

              {/* Exercise Selector */}
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                {exercises.map(ex => (
                  <button
                    key={ex.id}
                    onClick={() => addExerciseToWorkout(ex)}
                    className={cn(
                      "p-3 rounded-xl border text-sm font-medium transition-all text-left flex flex-col gap-1",
                      currentWorkout.some(c => c.exerciseId === ex.id)
                        ? "bg-emerald-50 border-emerald-200 text-emerald-700"
                        : "bg-white border-zinc-200 hover:border-emerald-300 hover:bg-emerald-50/30"
                    )}
                  >
                    <span className="truncate">{ex.name}</span>
                    <span className="text-[10px] uppercase tracking-wider opacity-60">{ex.category}</span>
                  </button>
                ))}
              </div>

              {/* Current Workout List */}
              <div className="space-y-4">
                {currentWorkout.map((ex) => (
                  <div key={ex.exerciseId} className="bg-white rounded-2xl border border-zinc-200 overflow-hidden shadow-sm">
                    <div className="p-4 border-b border-zinc-100 flex items-center justify-between bg-zinc-50/50">
                      <h3 className="font-bold text-lg">{ex.name}</h3>
                      <button 
                        onClick={() => removeExercise(ex.exerciseId)}
                        className="text-zinc-400 hover:text-red-500 transition-colors"
                      >
                        <Trash2 size={18} />
                      </button>
                    </div>
                    <div className="p-4 space-y-3">
                      <div className="grid grid-cols-12 gap-2 text-[10px] font-bold uppercase tracking-widest text-zinc-400 px-2">
                        <div className="col-span-2">Set</div>
                        <div className="col-span-4">Weight (kg)</div>
                        <div className="col-span-4">Reps</div>
                        <div className="col-span-2"></div>
                      </div>
                      {ex.sets.map((set, idx) => (
                        <div key={idx} className="grid grid-cols-12 gap-2 items-center">
                          <div className="col-span-2 font-mono text-zinc-400 text-center">{idx + 1}</div>
                          <div className="col-span-4">
                            <input
                              type="number"
                              value={set.weight || ""}
                              onChange={(e) => updateSet(ex.exerciseId, idx, "weight", parseFloat(e.target.value))}
                              className="w-full bg-zinc-100 border-none rounded-lg p-2 text-center font-semibold focus:ring-2 focus:ring-emerald-500"
                              placeholder="0"
                            />
                          </div>
                          <div className="col-span-4">
                            <input
                              type="number"
                              value={set.reps || ""}
                              onChange={(e) => updateSet(ex.exerciseId, idx, "reps", parseInt(e.target.value))}
                              className="w-full bg-zinc-100 border-none rounded-lg p-2 text-center font-semibold focus:ring-2 focus:ring-emerald-500"
                              placeholder="0"
                            />
                          </div>
                          <div className="col-span-2 flex justify-center">
                            {/* Optional: Remove set button */}
                          </div>
                        </div>
                      ))}
                      <button
                        onClick={() => addSet(ex.exerciseId)}
                        className="w-full py-2 border-2 border-dashed border-zinc-200 rounded-xl text-zinc-400 hover:text-emerald-500 hover:border-emerald-200 hover:bg-emerald-50 transition-all text-sm font-medium flex items-center justify-center gap-2"
                      >
                        <Plus size={16} />
                        Add Set
                      </button>
                    </div>
                  </div>
                ))}

                {currentWorkout.length === 0 && (
                  <div className="py-20 text-center space-y-4">
                    <div className="bg-zinc-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto text-zinc-400">
                      <Activity size={32} />
                    </div>
                    <div>
                      <p className="text-zinc-500 font-medium">No exercises added yet</p>
                      <p className="text-zinc-400 text-sm">Select an exercise above to start logging</p>
                    </div>
                  </div>
                )}
              </div>
            </motion.div>
          )}

          {activeTab === "history" && (
            <motion.div
              key="history"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="space-y-6"
            >
              <h2 className="text-2xl font-bold">Workout History</h2>
              <div className="space-y-4">
                {history.map((session) => (
                  <div key={session.id} className="bg-white rounded-2xl border border-zinc-200 p-4 shadow-sm">
                    <div className="flex items-center justify-between mb-4">
                      <div className="flex items-center gap-2">
                        <Calendar size={16} className="text-emerald-500" />
                        <span className="font-bold">{new Date(session.date).toLocaleDateString(undefined, { month: 'long', day: 'numeric', year: 'numeric' })}</span>
                      </div>
                      <span className="text-xs bg-zinc-100 px-2 py-1 rounded-full text-zinc-500 font-medium">
                        {session.exercises.length} Exercises
                      </span>
                    </div>
                    <div className="space-y-3">
                      {session.exercises.map((ex, idx) => (
                        <div key={idx} className="flex items-start justify-between text-sm">
                          <div>
                            <p className="font-semibold text-zinc-700">{ex.name}</p>
                            <p className="text-zinc-400 text-xs">
                              {ex.sets.map(s => `${s.weight}kg x ${s.reps}`).join(", ")}
                            </p>
                          </div>
                          <div className="text-right">
                            <p className="font-mono text-zinc-400 text-xs">
                              Vol: {ex.sets.reduce((acc, s) => acc + (s.weight * s.reps), 0)}kg
                            </p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
                {history.length === 0 && (
                  <div className="py-20 text-center text-zinc-400">
                    <p>No workouts logged yet.</p>
                  </div>
                )}
              </div>
            </motion.div>
          )}

          {activeTab === "stats" && (
            <motion.div
              key="stats"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="space-y-6"
            >
              <h2 className="text-2xl font-bold">Progress Insights</h2>
              
              <div className="bg-white rounded-2xl border border-zinc-200 p-4 shadow-sm">
                <label className="block text-xs font-bold uppercase tracking-widest text-zinc-400 mb-2">Select Exercise</label>
                <select 
                  className="w-full bg-zinc-50 border border-zinc-200 rounded-xl p-3 font-semibold focus:ring-2 focus:ring-emerald-500 outline-none"
                  onChange={(e) => setSelectedExerciseId(parseInt(e.target.value))}
                  value={selectedExerciseId || ""}
                >
                  <option value="" disabled>Choose an exercise...</option>
                  {exercises.map(ex => (
                    <option key={ex.id} value={ex.id}>{ex.name}</option>
                  ))}
                </select>
              </div>

              {selectedExerciseId && stats.length > 0 ? (
                <div className="space-y-6">
                  {/* Weight Chart */}
                  <div className="bg-white rounded-2xl border border-zinc-200 p-4 shadow-sm">
                    <h3 className="font-bold mb-4 flex items-center gap-2">
                      <TrendingUp size={18} className="text-emerald-500" />
                      Max Weight (kg)
                    </h3>
                    <div className="h-64 w-full">
                      <ResponsiveContainer width="100%" height="100%">
                        <AreaChart data={stats}>
                          <defs>
                            <linearGradient id="colorWeight" x1="0" y1="0" x2="0" y2="1">
                              <stop offset="5%" stopColor="#10b981" stopOpacity={0.3}/>
                              <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
                            </linearGradient>
                          </defs>
                          <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f0f0f0" />
                          <XAxis 
                            dataKey="date" 
                            axisLine={false} 
                            tickLine={false} 
                            tick={{ fontSize: 10, fill: '#a1a1aa' }}
                            dy={10}
                          />
                          <YAxis 
                            axisLine={false} 
                            tickLine={false} 
                            tick={{ fontSize: 10, fill: '#a1a1aa' }}
                          />
                          <Tooltip 
                            contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 4px 12px rgba(0,0,0,0.1)' }}
                          />
                          <Area 
                            type="monotone" 
                            dataKey="maxWeight" 
                            stroke="#10b981" 
                            strokeWidth={3}
                            fillOpacity={1} 
                            fill="url(#colorWeight)" 
                          />
                        </AreaChart>
                      </ResponsiveContainer>
                    </div>
                  </div>

                  {/* Volume Chart */}
                  <div className="bg-white rounded-2xl border border-zinc-200 p-4 shadow-sm">
                    <h3 className="font-bold mb-4 flex items-center gap-2">
                      <Activity size={18} className="text-blue-500" />
                      Total Volume (kg)
                    </h3>
                    <div className="h-64 w-full">
                      <ResponsiveContainer width="100%" height="100%">
                        <LineChart data={stats}>
                          <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f0f0f0" />
                          <XAxis 
                            dataKey="date" 
                            axisLine={false} 
                            tickLine={false} 
                            tick={{ fontSize: 10, fill: '#a1a1aa' }}
                            dy={10}
                          />
                          <YAxis 
                            axisLine={false} 
                            tickLine={false} 
                            tick={{ fontSize: 10, fill: '#a1a1aa' }}
                          />
                          <Tooltip 
                            contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 4px 12px rgba(0,0,0,0.1)' }}
                          />
                          <Line 
                            type="monotone" 
                            dataKey="volume" 
                            stroke="#3b82f6" 
                            strokeWidth={3}
                            dot={{ fill: '#3b82f6', strokeWidth: 2, r: 4 }}
                            activeDot={{ r: 6 }}
                          />
                        </LineChart>
                      </ResponsiveContainer>
                    </div>
                  </div>
                </div>
              ) : selectedExerciseId ? (
                <div className="py-20 text-center text-zinc-400">
                  <p>No data available for this exercise yet.</p>
                  <p className="text-sm">Log some workouts to see your progress!</p>
                </div>
              ) : (
                <div className="py-20 text-center text-zinc-400">
                  <p>Select an exercise to view progress charts.</p>
                </div>
              )}
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {/* Bottom Navigation */}
      <nav className="fixed bottom-0 left-0 right-0 bg-white border-t border-zinc-200 px-6 py-3 z-20">
        <div className="max-w-2xl mx-auto flex items-center justify-between">
          <button 
            onClick={() => setActiveTab("log")}
            className={cn(
              "flex flex-col items-center gap-1 transition-colors",
              activeTab === "log" ? "text-emerald-600" : "text-zinc-400 hover:text-zinc-600"
            )}
          >
            <Plus size={24} className={cn(activeTab === "log" && "scale-110 transition-transform")} />
            <span className="text-[10px] font-bold uppercase tracking-wider">Log</span>
          </button>
          <button 
            onClick={() => setActiveTab("history")}
            className={cn(
              "flex flex-col items-center gap-1 transition-colors",
              activeTab === "history" ? "text-emerald-600" : "text-zinc-400 hover:text-zinc-600"
            )}
          >
            <History size={24} className={cn(activeTab === "history" && "scale-110 transition-transform")} />
            <span className="text-[10px] font-bold uppercase tracking-wider">History</span>
          </button>
          <button 
            onClick={() => setActiveTab("stats")}
            className={cn(
              "flex flex-col items-center gap-1 transition-colors",
              activeTab === "stats" ? "text-emerald-600" : "text-zinc-400 hover:text-zinc-600"
            )}
          >
            <TrendingUp size={24} className={cn(activeTab === "stats" && "scale-110 transition-transform")} />
            <span className="text-[10px] font-bold uppercase tracking-wider">Progress</span>
          </button>
        </div>
      </nav>
    </div>
  );
}
